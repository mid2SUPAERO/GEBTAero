var interfaceglobaldatafun_1_1writevec =
[
    [ "writeintvector", "interfaceglobaldatafun_1_1writevec.html#acaa8979c629439920cf2fcd8dc39652d", null ],
    [ "writerealvector", "interfaceglobaldatafun_1_1writevec.html#a64fd9ea2d0b1776a2844c65a2e7ffac9", null ]
];