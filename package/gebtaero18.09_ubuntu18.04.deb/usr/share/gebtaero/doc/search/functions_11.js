var searchData=
[
  ['vecb',['vecb',['../namespaceglobaldatafun.html#a0ef3145b88a5e2f7679e5309ed885bc4',1,'globaldatafun']]],
  ['vecc',['vecc',['../namespaceglobaldatafun.html#ac274536794b3306528c0130a20080b15',1,'globaldatafun']]],
  ['vecd',['vecd',['../namespaceglobaldatafun.html#a71653a1d825c3dee70490c228d23b738',1,'globaldatafun']]]
];
