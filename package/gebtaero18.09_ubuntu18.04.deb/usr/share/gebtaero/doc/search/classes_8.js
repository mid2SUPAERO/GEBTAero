var searchData=
[
  ['prescriinf',['prescriinf',['../structprescribedcondition_1_1prescriinf.html',1,'prescribedcondition']]]
];
