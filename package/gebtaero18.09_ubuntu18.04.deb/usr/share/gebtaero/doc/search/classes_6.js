var searchData=
[
  ['memberinf',['memberinf',['../structinternaldata_1_1memberinf.html',1,'internaldata']]]
];
