var searchData=
[
  ['newtonraphsonmumps',['newtonraphsonmumps',['../namespacesolvemumps.html#a243ff65847b437ecb22933d782df2db4',1,'solvemumps']]],
  ['norm',['norm',['../namespaceglobaldatafun.html#a79010ea3a4434936e8a71182e62b6e48',1,'globaldatafun']]]
];
