var classgebtaero_1_1_wing_1_1_wing =
[
    [ "__init__", "classgebtaero_1_1_wing_1_1_wing.html#ad4899077f16bf8b8dff5e9ce86c4b2c0", null ],
    [ "AppendWingSection", "classgebtaero_1_1_wing_1_1_wing.html#ae2bcf197a55c10900d837bc0d9d6aac7", null ],
    [ "GetCrossSections", "classgebtaero_1_1_wing_1_1_wing.html#a15245b467e6be2a7ace9a917e67661ff", null ],
    [ "GetFrames", "classgebtaero_1_1_wing_1_1_wing.html#a0bd0def91e16cd1a19b10fcdf8c50e41", null ],
    [ "GetKpList", "classgebtaero_1_1_wing_1_1_wing.html#afe768db8f9a06bd5784143c1168a5acc", null ],
    [ "GetName", "classgebtaero_1_1_wing_1_1_wing.html#a180f53c7c326569cc0c8e8c78a3a0b2a", null ],
    [ "GetSurface", "classgebtaero_1_1_wing_1_1_wing.html#af0be9af67eb300ebc83262025f6c80af", null ],
    [ "GetWeight", "classgebtaero_1_1_wing_1_1_wing.html#a290d5e1d3a18de515339ffbed0f0df35", null ],
    [ "GetWingRootPosition", "classgebtaero_1_1_wing_1_1_wing.html#a6623e4ea917c8a03a3de9bbf7110e754", null ],
    [ "GetWingSections", "classgebtaero_1_1_wing_1_1_wing.html#a9fbfa35745a94279f37ebf497a36126e", null ],
    [ "ModifySectionLength", "classgebtaero_1_1_wing_1_1_wing.html#a3b5df3a1833448d36becf9a5a9f3e951", null ],
    [ "CrossSections", "classgebtaero_1_1_wing_1_1_wing.html#a31876f71184c1f5330aa22b2a51989ea", null ],
    [ "Frames", "classgebtaero_1_1_wing_1_1_wing.html#a4d4a29e2bd610166204d416d182b4b14", null ],
    [ "KpList", "classgebtaero_1_1_wing_1_1_wing.html#a85da9f70285dd5be8a0983fa39b70fec", null ],
    [ "Name", "classgebtaero_1_1_wing_1_1_wing.html#a1c41ea89cf72ec60090134497f1ede15", null ],
    [ "WingRootPosition", "classgebtaero_1_1_wing_1_1_wing.html#aa0957399544603f1df3cdb3b02eeda4a", null ],
    [ "WingSections", "classgebtaero_1_1_wing_1_1_wing.html#a87db863f3c208b18c8e7594d75598a1d", null ]
];