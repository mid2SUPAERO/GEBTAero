var structprescribedcondition_1_1prescriinf =
[
    [ "dof", "structprescribedcondition_1_1prescriinf.html#add1a1e3ab7bef3eaf011f074368c89f8", null ],
    [ "follower", "structprescribedcondition_1_1prescriinf.html#a7e97cae9888b22f4229b56b3a0d2e3b1", null ],
    [ "id", "structprescribedcondition_1_1prescriinf.html#ad7a7ffe265b06ff7c2a1487bb0b9cf56", null ],
    [ "time_fun_no", "structprescribedcondition_1_1prescriinf.html#afebb4f4446a4d4877901b4d777af811a", null ],
    [ "value", "structprescribedcondition_1_1prescriinf.html#a42fcd5b12e0a171e60ddf14041ab09aa", null ],
    [ "value_current", "structprescribedcondition_1_1prescriinf.html#adb8c3bfd5669cc2eccb447f24556ebaf", null ]
];