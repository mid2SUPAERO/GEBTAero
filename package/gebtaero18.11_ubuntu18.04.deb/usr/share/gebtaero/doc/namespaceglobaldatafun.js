var namespaceglobaldatafun =
[
    [ "writevec", "interfaceglobaldatafun_1_1writevec.html", "interfaceglobaldatafun_1_1writevec" ]
];