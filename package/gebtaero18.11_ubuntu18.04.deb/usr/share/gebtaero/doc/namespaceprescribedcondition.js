var namespaceprescribedcondition =
[
    [ "distriload", "structprescribedcondition_1_1distriload.html", "structprescribedcondition_1_1distriload" ],
    [ "prescriinf", "structprescribedcondition_1_1prescriinf.html", "structprescribedcondition_1_1prescriinf" ]
];