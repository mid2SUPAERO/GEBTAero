var namespaceinternaldata =
[
    [ "memberinf", "structinternaldata_1_1memberinf.html", "structinternaldata_1_1memberinf" ]
];