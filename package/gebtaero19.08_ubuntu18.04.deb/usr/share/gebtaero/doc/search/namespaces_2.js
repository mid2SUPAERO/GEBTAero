var searchData=
[
  ['disc',['Disc',['../namespace_disc.html',1,'']]]
];
