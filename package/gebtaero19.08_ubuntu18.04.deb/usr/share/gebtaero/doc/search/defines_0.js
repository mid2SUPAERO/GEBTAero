var searchData=
[
  ['bufsiz',['BUFSIZ',['../unical1__b_8c.html#a72a591cf0a96cf23c63df5c78712dabe',1,'unical1_b.c']]]
];
